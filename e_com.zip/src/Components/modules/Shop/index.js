import React from "react";
import Products from "../Home/component/Products";

export const Shop = () => {
  return <Products />;
};
